# Single-cohort Figure 1: 3-panel power summary
# (add_se_bars is defined in plot_with_se.R; local fallback below for standalone use)
if (!exists("add_se_bars")) {
  add_se_bars <- function(x, y, se, col, bar_width = 0.3) {
    valid <- !is.na(y) & !is.na(se) & se > 1e-6
    if (!any(valid)) return(invisible())
    arrows(x[valid], (y - se)[valid], x[valid], (y + se)[valid],
           angle = 90, code = 3, length = bar_width * 0.15,
           col = col, lwd = 1.2)
  }
}
# Panel A: marginal power vs n, lines = FDR thresholds
# Panel B: stratified power by r-stratum, lines per n
# Panel C: true discoveries by r-stratum (lines per n) + overlay of gene distribution

#' Plot single-cohort circadian power (3 panels)
#'
#' @description
#' Summarises a single-cohort power simulation in three panels: marginal
#' power against sample size at several FDR thresholds (Panel A), power
#' resolved by effect-size stratum (Panel B), and the number of true
#' discoveries by effect-size stratum (Panel C). It either draws to the
#' current device or writes a PDF.
#'
#' The panels can be produced two ways. Supply a precomputed
#' \code{\link{runSimsSingleCohort}} object as \code{res} (optionally with a
#' second object as \code{panel_a_res} that drives only the marginal panel).
#' Alternatively, supply the pilot and design directly through \code{bio.opts}
#' and \code{design.opts}: the marginal panel (A) is then computed from a run
#' over the pilot's own effect sizes, while the stratified panels (B and C) are
#' computed from a companion run that spreads gene effect sizes across the full
#' \eqn{r = A/\sigma} range so every stratum is populated. The caller never
#' specifies how effect sizes are drawn.
#'
#' @param res        Output from \code{\link{runSimsSingleCohort}}. May be
#'   \code{NULL} when \code{bio.opts} and \code{design.opts} are supplied, in
#'   which case the required simulations are run internally.
#' @param panel_a_res Optional alternate result object used for the Panel A
#'   marginal-power computation only. If NULL (default), Panel A is computed
#'   from \code{res}. Useful when the marginal summary should reflect a
#'   different empirical assumption than the effect-size-stratified panels.
#' @param out_pdf    Path for PDF output. If NULL, plots to current device.
#' @param title      Overall figure title (default empty).
#' @param panels     Character vector, which of panels "A" (marginal power vs
#'   n), "B" (power by effect-size stratum), "C" (true discoveries by
#'   effect-size stratum) to draw (default all three).
#' @param panel_labels Character vector of length 3 giving the letters printed on
#'   panels A, B, C respectively (default \code{c("A","B","C")}). Use e.g.
#'   \code{c("D","E","F")} for the lower figure in a vertically stacked pair.
#' @param fdr_thresholds FDR levels for panel A (default c(0.01,0.05,0.10,0.20)).
#' @param panel_fdr  FDR threshold highlighted in panels B/C (default 0.05).
#' @param vline_power Horizontal reference line for target power (default 0.80).
#' @param vline_fdr  FDR threshold marked with a reference guide (default 0.20).
#' @param fdr        Single-value alias that sets both \code{panel_fdr} and
#'   \code{vline_fdr} at once (back-compat convenience; default NULL).
#' @param p.adjust.method Correction method (default "BH").
#' @param reference_n    Reference sample size for annotations (default NULL = none).
#' @param display_sizes  Sample sizes to show in all panels (NULL = all).
#' @param r_max      Upper bound (r = A/sigma units) for the r-strata
#'   breakpoints; \code{NULL} adapts to the 95th percentile of observed r
#'   (default 5).
#' @param cex_main   Title character expansion (default 1.50).
#' @param cex_lab    Axis-label character expansion (default 1.60).
#' @param cex_axis   Axis-tick character expansion (default 1.45).
#' @param line_lwd   Line width for power curves (default 2).
#' @param pt_cex     Point character expansion for plotted markers (default 0.95).
#' @param legend_cex Legend text character expansion; \code{NULL} (default)
#'   picks a size automatically.
#' @param title_cex  Outer-title character expansion (default 1.65).
#' @param oma_top    Outer margin (lines) reserved above the panels for the
#'   title (default 2.4).
#' @param legend_pos Legend position keyword passed to \code{legend()}
#'   (default "bottomright").
#' @param se_cap     Maximum half-width (power units) drawn for standard-error
#'   bars, to keep long bars from overplotting neighboring panels (default 0.3).
#' @param vertical   Logical; if TRUE, stack panels vertically instead of the
#'   default horizontal 1 x length(panels) layout (default FALSE).
#' @param panel_c_legend Logical; if TRUE, also draw the legend on panel C
#'   (default FALSE; panel A's legend is normally sufficient).
#' @param width      PDF width in inches (default 15).
#' @param height     PDF height in inches (default 5.5).
#' @param bio.opts   Optional \code{CircadianBioOptions} pilot (e.g. from
#'   \code{\link{estCircadianParam}}). When supplied together with
#'   \code{design.opts}, and \code{panel_a_res} is \code{NULL}, the simulations
#'   backing the requested panels are run internally so the caller can go
#'   straight from a pilot to the figure. Ignored when \code{panel_a_res} is
#'   supplied (default \code{NULL}).
#' @param design.opts Optional \code{CircadianDesignOptions} used with
#'   \code{bio.opts} for the internal runs (default \code{NULL}).
#' @param analysis.opts Optional \code{CircadianAnalysisOptions} for the
#'   internal runs; defaults to \code{CircadianAnalysisOptions()} when
#'   \code{NULL}.
#' @param K          Cosinor harmonic order for the internal runs (1 =
#'   single-harmonic, 2 = two-harmonic; default 1).
#' @param mc.cores   Cores used for the internal simulation runs (default 1).
#' @return Invisibly returns list of data used per panel.
#' @examples
#' bio  <- scp_load_pilot("human", "GTEx", "Adrenal", "All")
#' bio$ngenes <- 200L
#' dopt <- CircadianDesignOptions(sample_sizes = c(24, 48), nsims = 5)
#' aopt <- CircadianAnalysisOptions(alpha = 0.05)
#' res  <- runSimsSingleCohort(bio, dopt, aopt, verbose = FALSE)
#' plotSingleCohortPower(res, out_pdf = tempfile(fileext = ".pdf"))
#' @export
plotSingleCohortPower <- function(res = NULL, out_pdf = NULL, title = "",
                                 panel_a_res = NULL,
                                 panels = c("A", "B", "C"),
                                 panel_labels = c("A", "B", "C"),
                                 fdr_thresholds = c(0.01, 0.05, 0.10, 0.20),
                                 panel_fdr = 0.05,
                                 vline_power = 0.80,
                                 vline_fdr   = 0.20,
                                 fdr = NULL,
                                 p.adjust.method = "BH",
                                 reference_n = NULL,
                                 display_sizes = NULL,
                                 r_max = 5,
                                 cex_main = 1.50, cex_lab = 1.60, cex_axis = 1.45,
                                 line_lwd = 2, pt_cex = 0.95, legend_cex = NULL,
                                 title_cex = 1.65, oma_top = 2.4,
                                 legend_pos = "bottomright", se_cap = 0.3,
                                 vertical = FALSE,
                                 panel_c_legend = FALSE,
                                 width = 15, height = 5.5,
                                 bio.opts = NULL, design.opts = NULL,
                                 analysis.opts = NULL, K = 1L, mc.cores = 1L) {
  # `fdr` is a single-value alias for panel_fdr + vline_fdr (back-compat)
  if (!is.null(fdr) && is.numeric(fdr) && length(fdr) == 1L) {
    panel_fdr <- fdr
    vline_fdr <- fdr
  }

  # Optional pilot-driven path. When a CircadianBioOptions pilot and a design
  # are supplied (and no explicit panel_a_res override is given), run the
  # simulations the requested panels need here, so the caller can go straight
  # from a pilot to the figure without staging a runSimsSingleCohort() object.
  #
  # Panel A (marginal power) is computed from a run over the pilot's own
  # effect sizes. Panels B and C need every effect-size stratum populated, so
  # when either is requested a companion run spreads gene effect sizes across
  # the full r = A/sigma range (sigma_rhythmic is resampled so it no longer
  # tracks amplitude) and drives the stratified panels. The caller never
  # chooses how effect sizes are drawn.
  #
  # When bio.opts is NULL the behaviour is exactly as before: `res` (and any
  # `panel_a_res`) are used as passed.
  if (!is.null(bio.opts) && is.null(panel_a_res)) {
    if (is.null(design.opts))
      stop("plotSingleCohortPower(): 'design.opts' is required when 'bio.opts' is supplied.")
    if (is.null(analysis.opts)) analysis.opts <- CircadianAnalysisOptions()

    want_bc <- any(c("B", "C") %in% intersect(c("A", "B", "C"), panels))

    res_marg <- runSimsSingleCohort(bio.opts, design.opts, analysis.opts,
                                    K = K, mc.cores = mc.cores, verbose = FALSE)

    if (want_bc) {
      bio_bc <- bio.opts
      sig <- bio_bc$sigma_rhythmic
      if (!is.null(sig) && length(sig) > 1L) {
        rng_state <- if (exists(".Random.seed", envir = .GlobalEnv, inherits = FALSE))
                       get(".Random.seed", envir = .GlobalEnv) else NULL
        set.seed(2025L)
        # Break the amplitude/sigma pairing so r = A/sigma spans its full
        # range and every stratum in panels B and C is populated.
        bio_bc$sigma_rhythmic <- sample(sig)
        if (!is.null(rng_state))
          assign(".Random.seed", rng_state, envir = .GlobalEnv)
      }
      res_bc <- runSimsSingleCohort(bio_bc, design.opts, analysis.opts,
                                    K = K, mc.cores = mc.cores, verbose = FALSE)
      res         <- res_bc     # stratified panels B and C
      panel_a_res <- res_marg   # marginal panel A
    } else {
      res <- res_marg
    }
  }

  if (is.null(res))
    stop("plotSingleCohortPower(): supply either 'res' or ('bio.opts' + 'design.opts').")
  # Adaptive r_max: pick the 95th percentile of observed r values across
  # all simulations so panels B and C only show populated strata (don't waste
  # space on r in (3, 5] when no gene has r > 1.5).
  if (is.null(r_max)) {
    r_pool <- unlist(lapply(res$r_values_list, function(rv) {
      unlist(lapply(rv, function(v) v[v > 0]), use.names = FALSE)
    }), use.names = FALSE)
    if (length(r_pool) > 0L) {
      r_max <- max(stats::quantile(r_pool, 0.95, na.rm = TRUE), 1.0)
      r_max <- ceiling(r_max * 2) / 2   # round up to nearest 0.5
    } else {
      r_max <- 5
    }
  }

  sample_sizes  <- res$sample_sizes
  nsims         <- res$nsims
  r_strata      <- res$r_strata
  strata_labels <- res$strata_labels
  n_sizes       <- length(sample_sizes)
  n_strata      <- length(strata_labels)
  n_thresh      <- length(fdr_thresholds)

  base_cols     <- c("darkgreen", "steelblue", "orange", "red", "purple", "brown", "magenta")
  thresh_cols   <- if (n_thresh <= length(base_cols)) base_cols[seq_len(n_thresh)]
                   else grDevices::rainbow(n_thresh)
  thresh_labels <- paste0("FDR ", round(100 * fdr_thresholds, 1), "%")
  size_colors   <- rainbow(n_sizes, s = 0.6, v = 0.8)

  # Which sample sizes to show in panels B and C (all by default)
  disp_idx <- if (!is.null(display_sizes))
                which(sample_sizes %in% display_sizes)
              else seq_len(n_sizes)

  # Recompute power and TD at each FDR threshold from raw pvalues
  # power_arr[size, stratum, threshold, sim]
  # TD_arr   [size, stratum, threshold, sim]
  power_arr <- array(NA_real_, dim = c(n_sizes, n_strata, n_thresh, nsims))
  TD_arr    <- array(NA_real_, dim = c(n_sizes, n_strata, n_thresh, nsims))

  for (j in seq_len(n_sizes)) {
    for (s in seq_len(nsims)) {
      pvals    <- res$pvalues[j, , s]
      r_values <- res$r_values_list[[j]][[s]]

      is_rhythmic <- r_values > 0   # non-rhythmic genes have r = 0 by construction

      # r-stratum per gene (NA for non-rhythmic)
      r_for_strat <- ifelse(is_rhythmic, r_values, 0)
      xgr <- cut(r_for_strat, breaks = r_strata, include.lowest = TRUE, labels = FALSE)
      xgr[!is_rhythmic] <- NA

      # BH correction
      qvals <- rep(1, length(pvals))
      pvals[is.na(pvals)] <- 1
      qvals <- p.adjust(pvals, method = p.adjust.method)

      for (t in seq_len(n_thresh)) {
        disc <- qvals <= fdr_thresholds[t]
        for (k in seq_len(n_strata)) {
          in_k  <- !is.na(xgr) & xgr == k
          td    <- sum(disc & is_rhythmic & in_k, na.rm = TRUE)
          n_tgt <- sum(is_rhythmic & in_k, na.rm = TRUE)
          TD_arr[j, k, t, s]    <- td
          power_arr[j, k, t, s] <- if (n_tgt > 0) td / n_tgt else NA_real_
        }
      }
    }
  }

  # Panel A: marginal power vs n, lines = FDR thresholds
  # marginal_sim[size, threshold, sim]
  marginal_sim <- array(NA_real_, dim = c(n_sizes, n_thresh, nsims))
  for (j in seq_len(n_sizes)) {
    for (s in seq_len(nsims)) {
      r_values    <- res$r_values_list[[j]][[s]]
      is_rhythmic <- r_values > 0
      n_tgt       <- sum(is_rhythmic)
      for (t in seq_len(n_thresh)) {
        td_total <- sum(TD_arr[j, , t, s], na.rm = TRUE)
        marginal_sim[j, t, s] <- if (n_tgt > 0) td_total / n_tgt else NA_real_
      }
    }
  }
  marginal_mean <- apply(marginal_sim, c(1, 2), mean, na.rm = TRUE)
  marginal_se   <- apply(marginal_sim, c(1, 2),
                         function(x) sd(x, na.rm = TRUE) / sqrt(sum(!is.na(x))))

  vline_n <- npower(res, target_power = vline_power, fdr = vline_fdr)$n

  # If a separate result object is supplied for Panel A, override the marginal
  # summary (mean, SE, N target) computed above. The effect-size strata in
  # Panels B and C continue to use the primary `res`.
  if (!is.null(panel_a_res)) {
    pa <- panel_a_res
    pa_nsizes  <- length(pa$sample_sizes)
    pa_marg_sim <- array(NA_real_, dim = c(pa_nsizes, n_thresh, pa$nsims))
    for (jj in seq_len(pa_nsizes)) {
      for (ss in seq_len(pa$nsims)) {
        rv2   <- pa$r_values_list[[jj]][[ss]]
        rhy2  <- rv2 > 0
        n_t2  <- sum(rhy2)
        pv2   <- pa$pvalues[jj, , ss]
        pv2[is.na(pv2)] <- 1
        qv2   <- p.adjust(pv2, method = p.adjust.method)
        for (tt in seq_len(n_thresh)) {
          disc2 <- qv2 <= fdr_thresholds[tt]
          pa_marg_sim[jj, tt, ss] <- if (n_t2 > 0) sum(disc2 & rhy2) / n_t2 else NA_real_
        }
      }
    }
    marginal_mean <- apply(pa_marg_sim, c(1, 2), mean, na.rm = TRUE)
    marginal_se   <- apply(pa_marg_sim, c(1, 2),
                           function(x) sd(x, na.rm = TRUE) / sqrt(sum(!is.na(x))))
    sample_sizes_a <- pa$sample_sizes
    disp_idx_a     <- if (!is.null(display_sizes))
                        which(sample_sizes_a %in% display_sizes)
                      else seq_along(sample_sizes_a)
    vline_n <- npower(pa, target_power = vline_power, fdr = vline_fdr)$n
  } else {
    sample_sizes_a <- sample_sizes
    disp_idx_a     <- disp_idx
  }

  # Panels B & C: stratum-level results at panel_fdr (closest in fdr_thresholds)
  idx_fdr5  <- which.min(abs(fdr_thresholds - panel_fdr))
  fdr_label <- sprintf("FDR %g%%", panel_fdr * 100)
  mean_TD <- apply(TD_arr[, , idx_fdr5, , drop = FALSE], c(1, 2),
                   mean, na.rm = TRUE)  # [size, stratum]
  se_TD   <- apply(TD_arr[, , idx_fdr5, , drop = FALSE], c(1, 2),
                   function(x) sd(x, na.rm = TRUE) / sqrt(sum(!is.na(x))))

  # Gene distribution by r: average counts across all sims and sample sizes
  count_mat <- matrix(0L, nrow = n_sizes * nsims, ncol = n_strata)
  row_i <- 1L
  for (j in seq_len(n_sizes)) {
    for (s in seq_len(nsims)) {
      rv  <- res$r_values_list[[j]][[s]]
      rhy <- rv > 0
      xg  <- cut(rv[rhy], breaks = r_strata, include.lowest = TRUE, labels = FALSE)
      count_mat[row_i, ] <- tabulate(xg, nbins = n_strata)
      row_i <- row_i + 1L
    }
  }
  gene_counts <- colMeans(count_mat)

  # Panel C: stratified power at FDR 5% by r-stratum, lines per n
  mean_pow <- apply(power_arr[, , idx_fdr5, , drop = FALSE], c(1, 2),
                    mean, na.rm = TRUE)  # [size, stratum]
  se_pow   <- apply(power_arr[, , idx_fdr5, , drop = FALSE], c(1, 2),
                    function(x) sd(x, na.rm = TRUE) / sqrt(sum(!is.na(x))))

  # Collapse strata with r >= r_max into a single ">r_max" bin
  left_bounds <- r_strata[-length(r_strata)]   # left boundary of each bin
  collapse_from <- which(left_bounds >= r_max)

  if (length(collapse_from) >= 2) {
    keep <- seq_len(min(collapse_from) - 1)

    gene_counts_plt <- c(gene_counts[keep], sum(gene_counts[collapse_from]))

    mean_TD_plt <- cbind(mean_TD[, keep, drop = FALSE],
                         rowSums(mean_TD[, collapse_from, drop = FALSE]))
    se_TD_plt   <- cbind(se_TD[, keep, drop = FALSE],
                         sqrt(rowSums(se_TD[, collapse_from, drop = FALSE]^2)))

    gc_merged <- sum(gene_counts[collapse_from])
    if (gc_merged > 0) {
      pow_merged <- rowSums(mean_TD[, collapse_from, drop = FALSE]) / gc_merged
    } else {
      pow_merged <- rep(0, n_sizes)
    }
    mean_pow_plt <- cbind(mean_pow[, keep, drop = FALSE], pow_merged)
    se_pow_plt   <- cbind(se_pow[, keep, drop = FALSE],
                          matrix(NA_real_, n_sizes, 1))

    strata_labels_plt <- c(strata_labels[keep], sprintf(">%g", r_max))
    n_strata_plt      <- length(strata_labels_plt)
  } else {
    gene_counts_plt   <- gene_counts
    mean_TD_plt       <- mean_TD;  se_TD_plt  <- se_TD
    mean_pow_plt      <- mean_pow; se_pow_plt <- se_pow
    strata_labels_plt <- strata_labels
    n_strata_plt      <- n_strata
  }

  # Open device
  panels <- intersect(c("A", "B", "C"), panels)
  if (length(panels) == 0L) panels <- c("A", "B", "C")
  if (!is.null(out_pdf)) pdf(out_pdf, width = width, height = height)
  extra_lab    <- max(0, cex_lab - 1.55)
  needs_strata <- any(c("B", "C") %in% panels)
  mai_left  <- 0.85 + (if (needs_strata) 2.8 else 1.25) * extra_lab
  mai_bot   <- 1.03 + (if (needs_strata) 3.6 else 0.6) * extra_lab
  mgp_bc1   <- 5.2 + 6.0 * extra_lab
  par(mfrow = if (isTRUE(vertical)) c(length(panels), 1L) else c(1L, length(panels)),
      mai = c(mai_bot, mai_left, 0.52, 0.28),
      mgp = c(3.2, 0.65, 0), oma = c(0, 0, oma_top, 0),
      cex.axis = cex_axis, cex.lab = cex_lab, cex.main = cex_main, font.main = 2)
  on.exit({ if (!is.null(out_pdf)) dev.off() }, add = TRUE)

  sample_legend_n <- length(disp_idx)
  sample_legend_cols <- if (sample_legend_n > 16L) 3L else if (sample_legend_n > 6L) 2L else 1L
  sample_legend_cex <- if (sample_legend_n > 24L) 0.70 else if (sample_legend_n > 12L) 0.80 else 0.85
  if (!is.null(legend_cex)) {
    sample_legend_cex <- sample_legend_cex * (legend_cex / 1.05)
    panel_a_legend_cex <- legend_cex
  } else {
    panel_a_legend_cex <- 1.05
  }

  if ("A" %in% panels) {
  # ---- Panel A: marginal power vs n, multiple FDR lines ----
  ss_disp_a <- sample_sizes_a[disp_idx_a]
  matplot(ss_disp_a, 100 * marginal_mean[disp_idx_a, , drop = FALSE],
          type = "b", pch = 19, lwd = line_lwd, cex = pt_cex,
          col = thresh_cols, lty = 1,
          xlim = c(0, max(ss_disp_a) * 1.05), ylim = c(0, 100),
          xlab = "Sample size (N)", ylab = "Power (%)",
          main = "")
  title(main = paste0(panel_labels[1], "   Power vs Sample Size"),
        adj = 0.5, font.main = 2, cex.main = cex_main, line = 0.95)
  for (t in seq_len(n_thresh)) {
    add_se_bars(ss_disp_a, 100 * marginal_mean[disp_idx_a, t],
                100 * marginal_se[disp_idx_a, t], col = thresh_cols[t],
                bar_width = se_cap)
  }
  if (!is.null(reference_n)) {
    abline(v = reference_n, lty = 3, col = "darkgreen", lwd = 1.5)
  }
  abline(h = 80, lty = 2, col = "grey50", lwd = 1.2)
  grid()
  legend(legend_pos, title = NULL, legend = thresh_labels,
         col = thresh_cols, lty = 1, pch = 19, lwd = line_lwd,
         cex = panel_a_legend_cex, bty = "o", bg = "white", box.col = "grey50", box.lwd = 0.8,
         text.col = "black", title.col = "black",
         inset = c(0.02, 0.02), y.intersp = 0.88, title.adj = 0,
         seg.len = 1.1, x.intersp = 0.5)
  if (!is.na(vline_n)) {
    abline(v = vline_n, lty = 2, col = adjustcolor("steelblue", 0.7), lwd = 1.5)
    text(vline_n, 35, sprintf("N=%d", vline_n),
         col = "steelblue", cex = panel_a_legend_cex, adj = c(-0.10, 0.5), font = 2)
  }
  }  # end Panel A

  if ("B" %in% panels) {
  # ---- Panel B: stratified power by r, lines per n ----
  par(mgp = c(mgp_bc1, 0.6, 0))
  matplot(seq_len(n_strata_plt), 100 * t(mean_pow_plt[disp_idx, , drop = FALSE]),
          type = "l", lwd = line_lwd, col = size_colors[disp_idx], lty = 1,
          xlim = c(0.5, n_strata_plt + 0.5), ylim = c(0, 100), bty = "l",
          xlab = expression(r == A/sigma), ylab = "Power (%)",
          main = "",
          xaxt = "n")
  title(main = bquote(bold(.(paste0(panel_labels[2], "   "))) * bold("Stratified Power") ~
                       bold(.(sprintf("(%s)", fdr_label)))),
        adj = 0.5, font.main = 2, cex.main = cex_main, line = 0.95)
  axis(1, at = seq_len(n_strata_plt), labels = strata_labels_plt, las = 2, cex.axis = max(1.15, cex_axis * 0.8))
  for (j in disp_idx) {
    points(seq_len(n_strata_plt), 100 * mean_pow_plt[j, ],
           pch = 19, col = size_colors[j], cex = pt_cex)
    add_se_bars(seq_len(n_strata_plt), 100 * mean_pow_plt[j, ],
                100 * se_pow_plt[j, ], col = size_colors[j], bar_width = se_cap)
  }
  grid()
  legend(legend_pos, title = NULL, legend = paste0("N = ", sample_sizes[disp_idx]),
         col = size_colors[disp_idx], lty = 1, lwd = 2,
         cex = sample_legend_cex, bty = "o", bg = "white",
         box.col = "grey50", box.lwd = 0.8,
         text.col = "black", title.col = "black",
         inset = c(0.02, 0.02), y.intersp = 0.85, title.adj = 0,
         seg.len = 0.7, x.intersp = 0.35, ncol = sample_legend_cols)
  }  # end Panel B

  if ("C" %in% panels) {
  # ---- Panel C: TD by r-stratum, n lines + overlaid gene distribution ----
  y_max_TD      <- max(gene_counts_plt) * 1.15
  scaled_counts <- gene_counts_plt

  plot(seq_len(n_strata_plt), rep(0, n_strata_plt),
       type = "n", bty = "l",
       xlim = c(0.5, n_strata_plt + 0.5), ylim = c(0, y_max_TD),
       xlab = expression(r == A/sigma), ylab = "# True Discoveries",
       main = "",
       xaxt = "n")
  title(main = bquote(bold(.(paste0(panel_labels[3], "   "))) * bold("True Discoveries") ~
                       bold(.(sprintf("(%s)", fdr_label)))),
        adj = 0.5, font.main = 2, cex.main = cex_main, line = 0.95)
  axis(1, at = seq_len(n_strata_plt), labels = strata_labels_plt, las = 2, cex.axis = max(1.15, cex_axis * 0.8))

  step_x <- rep(seq(0.5, n_strata_plt + 0.5, by = 1), each = 2)
  step_y <- c(0, rep(scaled_counts, each = 2), 0)
  polygon(step_x, step_y, col = "#cccccc55", border = NA)
  lines(step_x, step_y, col = "grey60", lwd = 1.5, lty = 2)

  for (j in disp_idx) {
    lines(seq_len(n_strata_plt), mean_TD_plt[j, ], col = size_colors[j], lwd = line_lwd)
    points(seq_len(n_strata_plt), mean_TD_plt[j, ], pch = 19, col = size_colors[j], cex = pt_cex)
    add_se_bars(seq_len(n_strata_plt), mean_TD_plt[j, ], se_TD_plt[j, ], col = size_colors[j],
                bar_width = se_cap)
  }
  grid()
  if (isTRUE(panel_c_legend)) {
    legend(legend_pos, title = NULL,
           legend = c(paste0("N = ", sample_sizes[disp_idx]), "Target gene count"),
           col = c(size_colors[disp_idx], "grey60"), lty = c(rep(1, length(disp_idx)), 2),
           lwd = c(rep(2, length(disp_idx)), 1.5),
           cex = sample_legend_cex, bty = "o", bg = "white",
           box.col = "grey50", box.lwd = 0.8,
           text.col = "black", title.col = "black",
           inset = c(0.02, 0.02), y.intersp = 0.95, title.adj = 0,
           seg.len = 1.2, x.intersp = 0.6, ncol = sample_legend_cols)
  }
  par(mgp = c(3.0, 0.6, 0))   # restore
  }  # end Panel C

  if (nchar(title) > 0)
    mtext(title, outer = TRUE, side = 3, line = 0.12, cex = title_cex, font = 2)

  invisible(list(marginal_mean = marginal_mean, marginal_se = marginal_se,
                 mean_TD = mean_TD, mean_pow = mean_pow))
}
